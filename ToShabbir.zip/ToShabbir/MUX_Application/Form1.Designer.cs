﻿namespace MUX_Application
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            label1 = new Label();
            btn_imp = new Button();
            menuStrip1 = new MenuStrip();
            helpToolStripMenuItem = new ToolStripMenuItem();
            aboutMUXReportGeneratorToolToolStripMenuItem = new ToolStripMenuItem();
            btn_grt = new Button();
            lbl_nooffiles = new Label();
            statusStrip1 = new StatusStrip();
            status_info = new ToolStripStatusLabel();
            toolStripStatusLabel1 = new ToolStripStatusLabel();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            menuStrip1.SuspendLayout();
            statusStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(12, 41);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(164, 74);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(621, 31);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(151, 84);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 1;
            pictureBox2.TabStop = false;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top;
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(255, 128, 128);
            label1.Font = new Font("Segoe UI", 30F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = SystemColors.HotTrack;
            label1.Location = new Point(281, 216);
            label1.Name = "label1";
            label1.Size = new Size(230, 67);
            label1.TabIndex = 2;
            label1.Text = "Ford ITV";
            // 
            // btn_imp
            // 
            btn_imp.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            btn_imp.AutoSize = true;
            btn_imp.Cursor = Cursors.Hand;
            btn_imp.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btn_imp.ForeColor = SystemColors.ActiveCaptionText;
            btn_imp.Location = new Point(115, 262);
            btn_imp.Name = "btn_imp";
            btn_imp.Size = new Size(160, 51);
            btn_imp.TabIndex = 3;
            btn_imp.Text = "Import";
            btn_imp.UseVisualStyleBackColor = true;
            btn_imp.Click += btn_imp_grt_Click;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { helpToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 28);
            menuStrip1.TabIndex = 4;
            menuStrip1.Text = "menuStrip1";
            // 
            // helpToolStripMenuItem
            // 
            helpToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { aboutMUXReportGeneratorToolToolStripMenuItem });
            helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            helpToolStripMenuItem.Size = new Size(55, 24);
            helpToolStripMenuItem.Text = "Help";
            // 
            // aboutMUXReportGeneratorToolToolStripMenuItem
            // 
            aboutMUXReportGeneratorToolToolStripMenuItem.Name = "aboutMUXReportGeneratorToolToolStripMenuItem";
            aboutMUXReportGeneratorToolToolStripMenuItem.Size = new Size(320, 26);
            aboutMUXReportGeneratorToolToolStripMenuItem.Text = "About MUX Report generator Tool";
            aboutMUXReportGeneratorToolToolStripMenuItem.Click += aboutMUXReportGeneratorToolToolStripMenuItem_Click;
            // 
            // btn_grt
            // 
            btn_grt.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            btn_grt.Cursor = Cursors.Hand;
            btn_grt.Enabled = false;
            btn_grt.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point);
            btn_grt.ForeColor = SystemColors.ActiveCaptionText;
            btn_grt.Location = new Point(517, 262);
            btn_grt.Name = "btn_grt";
            btn_grt.Size = new Size(160, 51);
            btn_grt.TabIndex = 5;
            btn_grt.Text = "Generate";
            btn_grt.UseVisualStyleBackColor = true;
            btn_grt.Click += btn_grt_Click;
            // 
            // lbl_nooffiles
            // 
            lbl_nooffiles.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
            lbl_nooffiles.AutoSize = true;
            lbl_nooffiles.ForeColor = SystemColors.ActiveCaptionText;
            lbl_nooffiles.Location = new Point(115, 326);
            lbl_nooffiles.Name = "lbl_nooffiles";
            lbl_nooffiles.Size = new Size(173, 20);
            lbl_nooffiles.TabIndex = 6;
            lbl_nooffiles.Text = "Number of Files selected";
            // 
            // statusStrip1
            // 
            statusStrip1.ImageScalingSize = new Size(20, 20);
            statusStrip1.Items.AddRange(new ToolStripItem[] { status_info, toolStripStatusLabel1 });
            statusStrip1.Location = new Point(0, 424);
            statusStrip1.Name = "statusStrip1";
            statusStrip1.Size = new Size(800, 26);
            statusStrip1.TabIndex = 7;
            statusStrip1.Text = "statusStrip1";
            // 
            // status_info
            // 
            status_info.Name = "status_info";
            status_info.Size = new Size(0, 20);
            // 
            // toolStripStatusLabel1
            // 
            toolStripStatusLabel1.BackColor = SystemColors.Control;
            toolStripStatusLabel1.ForeColor = SystemColors.ActiveCaptionText;
            toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            toolStripStatusLabel1.Size = new Size(49, 20);
            toolStripStatusLabel1.Text = "Status";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 255, 192);
            ClientSize = new Size(800, 450);
            Controls.Add(statusStrip1);
            Controls.Add(lbl_nooffiles);
            Controls.Add(btn_grt);
            Controls.Add(btn_imp);
            Controls.Add(label1);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(menuStrip1);
            ForeColor = SystemColors.ControlLightLight;
            MainMenuStrip = menuStrip1;
            Name = "Form1";
            Text = "Danlaw MUX Report Generator V1.0";
            WindowState = FormWindowState.Maximized;
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            statusStrip1.ResumeLayout(false);
            statusStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private Label label1;
        private Button btn_imp;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem aboutMUXReportGeneratorToolToolStripMenuItem;
        private Button btn_grt;
        private Label lbl_nooffiles;
        private StatusStrip statusStrip1;
        private ToolStripStatusLabel status_info;
        private ToolStripStatusLabel toolStripStatusLabel1;
    }
}