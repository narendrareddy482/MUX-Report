﻿using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Wordprocessing;

namespace MUX_Application
{
    internal class OutsideVerticalBorder
    {
        public EnumValue<BorderValues> Val { get; set; }
        public int Size { get; set; }
    }
}