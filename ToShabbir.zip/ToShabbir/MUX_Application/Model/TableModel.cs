﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MUX_Application.Model
{
    public class TableModel
    {
        public string TestName { get; set; }
        public string TestResult { get; set; }
        public string TestComments { get; set; }

        //public bool IsAvailable {  get; set; }
    }
}
