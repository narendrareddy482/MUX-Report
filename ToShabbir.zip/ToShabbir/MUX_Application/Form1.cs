using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;
using System.Reflection.Metadata;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using Document = DocumentFormat.OpenXml.Wordprocessing.Document;
using Paragraph = DocumentFormat.OpenXml.Wordprocessing.Paragraph;
using Run = DocumentFormat.OpenXml.Wordprocessing.Run;
using Body = DocumentFormat.OpenXml.Wordprocessing.Body;
using Table = DocumentFormat.OpenXml.Wordprocessing.Table;
using DocumentFormat.OpenXml; // all headers are inbuilt packages
using MUX_Application.Model;
using System.Text.RegularExpressions;
using DocumentFormat.OpenXml.Vml;
using DocumentFormat.OpenXml.Drawing.Charts;

namespace MUX_Application
{
    public partial class Form1 : Form // to create class
    {
        List<string> file_name_list;// = new List<string>(); // for saving the selected file names
        Dictionary<string, List<string>> TestReportTemplate = new Dictionary<string, List<string>>();
        Dictionary<string, List<TestModel>> TestReport = new Dictionary<string, List<TestModel>>();
        // dictionary for report template
        public Form1() // this is a default constructor to initialize default values
        {
            InitializeComponent();
        }

        private void btn_imp_grt_Click(object sender, EventArgs e) // method for import button click
        {
            OpenFileDialog ofd = new OpenFileDialog(); //created object for openDailogue
            ofd.Filter = "(*.rtf)|*.rtf|All Files(*.*)|*.*";
            ofd.Multiselect = true;
            ofd.ShowDialog();
            file_name_list = ofd.FileNames.ToList();
            lbl_nooffiles.Text = file_name_list.Count + " File(s) Selected";
            btn_grt.Enabled = true;
        }

        private void aboutMUXReportGeneratorToolToolStripMenuItem_Click(object sender, EventArgs e)
        {
            // DialogResult dr =  MessageBox.Show("Do you want to continue?","File Error",MessageBoxButtons.YesNo, MessageBoxIcon.Error);
            // if(dr == DialogResult.Yes) { }
            //else { }
            MessageBox.Show("MUX Report Generator"); // Help button

        }

        private void Form1_Load(object sender, EventArgs e) // method for initilizing report templete
        {
            List<string> Test_name1 = new List<string>();
            Test_name1.Add("3.1.1 Power-Up/Initialization Performance");
            TestReportTemplate.Add("3.1 COMMUNICATION ROBUSTNESS", Test_name1);
            List<string> Test_name2 = new List<string>();
            Test_name2.Add("3.1.2.1 AUTOSAR NM LOCAL WAKEUP");
            Test_name2.Add("3.1.2.2 AUTOSAR NM NETWORK WAKEUP");
            Test_name2.Add("3.1.2.3 NETWORK DROWSY WAKE-UP SWEEP TEST");
            TestReportTemplate.Add("3.1.2 SLEEP/WAKE-UP PERFORMANCE", Test_name2);
            List<string> Test_name3 = new List<string>();
            Test_name3.Add("3.1.3.1 PERIODIC TRANSFER TEST");
            Test_name3.Add("3.1.3.2 EVENT PERIODIC TRANSFER TEST");
            Test_name3.Add("3.1.3.3 EVENT ON CHANGE TRANSFER TEST");
            Test_name3.Add("3.1.3.4 EVENT ON-WRITE TRANSFER TEST");
            Test_name3.Add("3.1.3.5 ROGUE MESSAGE DETECTION");
            Test_name3.Add("3.1.4 EXTENDED HEADER TOLERANCE");
            Test_name3.Add("3.1.5 FULL BANDWIDTH TOLERANCE");
            Test_name3.Add("3.1.6 BUS OFF HANDLER");
            TestReportTemplate.Add("3.1.3 TRANSFER STRATEGY ACCURACY", Test_name3);
            List<string> Test_name4 = new List<string>();
            Test_name4.Add("3.2.1 FNOS PACKAGE ID VERIFICATION");
            Test_name4.Add("3.2.2 AUTOSAR DIAGNOSTIC KEEP ALIVE");
            TestReportTemplate.Add("3.2 MUX DIAGNOSTICS TESTS", Test_name4);
            List<string> Test_name5 = new List<string>();
            Test_name5.Add("3.3.1 CAN CIRCUIT SHORTS");
            Test_name5.Add("3.3.2 CAN-HI GROUND SHORT WITH POWER-ON RESET");
            Test_name5.Add("3.3.3 CAN-HI BATTERY SHORT WITH POWER-ON RESET");
            Test_name5.Add("3.3.4 CAN-LO GROUND SHORT WITH POWER-ON RESET");
            Test_name5.Add("3.3.5 CAN-LO BATTERY SHORT WITH POWER-ON RESET");
            Test_name5.Add("3.3.6 CAN-HI To CAN-LO SHORT WITH POWER-ON RESET");
            TestReportTemplate.Add("3.3 FAULT TOLERANCE", Test_name5);
            List<string> Test_name6 = new List<string>();
            Test_name6.Add("3.4.1.1 LOW VOLTAGE SENSITIVITY");
            Test_name6.Add("3.4.1.2 HIGH VOLTAGE SENSITIVITY");
            Test_name6.Add("3.4.2.1 (+) GROUND OFFSET/LINE CAPACITANCE SENSITIV");
            Test_name6.Add("3.4.2.2 (-) GROUND OFFSET/LINE CAPACITANCE SENSITIVITY");
            Test_name6.Add("3.4.3 TERMINATION RESISTANCE ACCURACY");
            TestReportTemplate.Add("3.4 ELECTRICAL ROBUSTNESS", Test_name6);

        }

        private void btn_grt_Click(object sender, EventArgs e)
        {
            try // exception handle 
            {
                TestReport = new Dictionary<string, List<TestModel>>();

                //string line;
                //foreach (string rtffile in file_name_list)
                //{
                //    StreamReader sr = new StreamReader(rtffile);
                //    //Read the first line of text
                //    line = sr.ReadLine();
                //    //Continue to read until you reach end of file

                //}
                string[] wordsToRemove = { @"\viewkind4", @"\uc1", @"\pard", @"\f0", @"\fs20", @"\cf0", @"\cf1", @"\cf2", @"\cf3", @"\cf4", @"\rtlch", @"\fcs1",
                    @"\af43", @"\afs20", @"\ltrch", @"\fcs0", @"\f431", @"\kerning0",@"{",@"}", @"\insrsid3868228", @"\hich", @"\af43", @"\dbch", @"\af31505", @"\loch", @"\f43" };//@"\par",s

                foreach (string testCat in TestReportTemplate.Keys)
                {
                    List<TestModel> list = new List<TestModel>();
                    foreach (string testName in TestReportTemplate[testCat])
                    {
                        bool rtfFileFound = false;
                        string[] testSplit = testName.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries);
                        if (testSplit.Length > 0)
                        {
                            foreach (string fileName in file_name_list)
                            {
                                if (fileName.Contains(testSplit[0]))
                                {
                                    if (File.Exists(fileName))
                                    {
                                        rtfFileFound = true;
                                        string fileContent = File.ReadAllText(fileName);
                                        string modifiedString = string.Join("", fileContent.Split(wordsToRemove, StringSplitOptions.None));
                                        bool found = false;
                                        foreach (string line in modifiedString.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries))
                                        {
                                            if (line.ToLower().Contains(testName.ToLower()))
                                            {
                                                string testRes = line.Replace("\\par", "");
                                                string[] resultString = testRes.Split(new string[] { " - " }, StringSplitOptions.RemoveEmptyEntries);
                                                TestModel testModel = new TestModel();
                                                testModel.TestName = testName;
                                                testModel.TestResult = GetResult(resultString);// resultString[resultString.Length - 1];
                                                testModel.TestDescription = string.Format("{0} \r\n And \r\n {1}", FindNextLine(modifiedString.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries), "for the output CAN data file:"), FindNextLine(modifiedString.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries), "for the output text report file:"));
                                                list.Add(testModel);
                                                found = true;
                                            }
                                        }
                                        if (!found)
                                        {
                                            TestModel testModel = new TestModel();
                                            testModel.TestName = testName;
                                            testModel.TestResult = "N/A";
                                            testModel.TestDescription = string.Format("{0} \r\n And \r\n {1}", FindNextLine(modifiedString.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries), "for the output CAN data file:"), FindNextLine(modifiedString.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries), "for the output text report file:"));
                                            list.Add(testModel);
                                        }
                                    }
                                }
                            }
                        }
                        if (!rtfFileFound)
                        {
                            TestModel testModel = new TestModel();
                            testModel.TestName = testName;
                            testModel.TestResult = "N/A";
                            testModel.TestDescription = "N/A";
                            list.Add(testModel);
                        }

                    }
                    TestReport.Add(testCat, list);
                }

                SaveFileDialog saveFileDialog = new SaveFileDialog();
                saveFileDialog.ShowDialog();
                if (File.Exists("Template.doc"))
                {
                    using (WordprocessingDocument doc = WordprocessingDocument.Create(saveFileDialog.FileName, WordprocessingDocumentType.Document))
                    {
                        MainDocumentPart mainPart = doc.AddMainDocumentPart();

                        mainPart.Document = new Document();
                        Body body = mainPart.Document.AppendChild(new Body());

                        Paragraph Headerpara = new Paragraph();
                        Headerpara.ParagraphProperties = new ParagraphProperties(new Justification { Val = JustificationValues.Center });

                        Run Headrun = Headerpara.AppendChild(new Run());
                        RunProperties rp = Headrun.RunProperties = new RunProperties();
                        //rp.AppendChild(new DocumentFormat.OpenXml.Spreadsheet.FontFamily { Val =  });
                        rp.AppendChild(new FontSize { Val = "48" });
                        rp.AppendChild(new Bold { Val = OnOffValue.FromBoolean(true) });
                        rp.AppendChild(new Underline { Val = UnderlineValues.Single });

                        Headrun.AppendChild(new Text("FORD CGEA CAN"));
                        Headrun.AppendChild(new Break());
                        Headrun.AppendChild(new Text("ECU TEST DATA RECORD"));
                        body.Append(Headerpara);

                        Table Ptable = new Table();
                        TableRow row1 = new TableRow();
                        row1.AppendChild(CreateTestDesCell("Name : "));
                        row1.AppendChild(CreateRightCell(" "));
                        row1.AppendChild(CreateRightCell("Program : "));
                        Ptable.AppendChild(row1);
                        TableRow row2 = new TableRow();
                        row2.AppendChild(CreateTestDesCell("Date : " + DateTime.Now.ToString("MM/dd/yyyy")));
                        row2.AppendChild(CreateRightCell(" "));
                        row2.AppendChild(CreateRightCell("Location :41131 Vincenti Ct, Novi, Michigan 48375 "));
                        Ptable.AppendChild(row2);

                        body.Append(Ptable);

                        Paragraph SubHeaderpara = body.AppendChild(new Paragraph());
                        SubHeaderpara.ParagraphProperties = new ParagraphProperties(new Justification { Val = JustificationValues.Left });

                        Run SubHeadrun = SubHeaderpara.AppendChild(new Run());
                        RunProperties rpsub = SubHeadrun.RunProperties = new RunProperties();
                        //rp.AppendChild(new DocumentFormat.OpenXml.Spreadsheet.FontFamily { Val =  });
                        rpsub.AppendChild(new FontSize { Val = "22" });
                        //rpsub.AppendChild(new Bold { Val = OnOffValue.FromBoolean(true) });
                        rpsub.AppendChild(new Underline { Val = UnderlineValues.Single });

                        SubHeadrun.AppendChild(new Text("Purpose of Test (please check one of the following):"));
                        SubHeadrun.AppendChild(new Break());
                        SubHeadrun.AppendChild(new Text("Type of ECU Under Test:"));
                        SubHeadrun.AppendChild(new Break());
                        SubHeadrun.AppendChild(new Text("ECU Core Assembly (DID 0xF113): "));
                        SubHeadrun.AppendChild(new Break());
                        SubHeadrun.AppendChild(new Text("ECU Software Part Number (DID 0xF188): "));
                        SubHeadrun.AppendChild(new Break());
                        SubHeadrun.AppendChild(new Text("Test Specification: "));
                        SubHeadrun.AppendChild(new Break());
                        SubHeadrun.AppendChild(new Text("Test Tool:"));
                        SubHeadrun.AppendChild(new Break());

                        Run SubHeadrun1 = SubHeaderpara.AppendChild(new Run());
                        RunProperties rpsub1 = SubHeadrun1.RunProperties = new RunProperties();
                        //rp.AppendChild(new DocumentFormat.OpenXml.Spreadsheet.FontFamily { Val =  });
                        rpsub1.AppendChild(new FontSize { Val = "19" });
                        //rpsub.AppendChild(new Bold { Val = OnOffValue.FromBoolean(true) });
                        //rpsub1.AppendChild(new Underline { Val = UnderlineValues.Single });

                        SubHeadrun1.AppendChild(new Text("Insert �PASS� or �FAIL� in the RESULT field and any measured/calculated values in the VALUE field when applicable."));

                        // Create a table
                        Table table = new Table();
                        TableProperties tableProperties = new TableProperties(new TableBorders(
                            new TopBorder { Val = new EnumValue<BorderValues>(BorderValues.Double), Size = 6 },
                            new BottomBorder { Val = new EnumValue<BorderValues>(BorderValues.Double), Size = 6 },
                            new LeftBorder { Val = new EnumValue<BorderValues>(BorderValues.Double), Size = 6 },
                            new RightBorder { Val = new EnumValue<BorderValues>(BorderValues.Double), Size = 6 },
                            new InsideHorizontalBorder { Val = new EnumValue<BorderValues>(BorderValues.Single), Size = 6 },
                            new InsideVerticalBorder { Val = new EnumValue<BorderValues>(BorderValues.Single), Size = 6 }
                        ));
                        table.AppendChild(tableProperties);

                        // Add table headers
                        TableRow headerRow = new TableRow();

                        //headerRow.Append(CreateHeaderCell("S.No"));
                        headerRow.Append(CreateHeaderCell("TEST"));
                        headerRow.Append(CreateHeaderCell("RESULT"));
                        headerRow.Append(CreateHeaderCell("COMMENT"));
                        table.AppendChild(headerRow);


                        foreach (string category in TestReport.Keys)
                        {
                            TableRow dataRow = new TableRow();
                            dataRow.Append(CreateCategoryCell(category));
                            dataRow.Append(CreateCategoryCell(" "));
                            dataRow.Append(CreateCategoryCell(" "));
                            table.AppendChild(dataRow);
                            foreach (TestModel testModel in TestReport[category])
                            {
                                TableRow testRow = new TableRow();
                                testRow.Append(CreateCell(testModel.TestName));
                                testRow.Append(CreateCell(testModel.TestResult));
                                testRow.Append(CreateTestDesCell(testModel.TestDescription));
                                table.AppendChild(testRow);
                            }
                        }

                        body.Append(table);



                        MessageBox.Show("Report Generated at : " + saveFileDialog.FileName);
                    }
                }
                // Set the response headers for downloading the file
                //Response.Headers.Add("Content-Disposition", "attachment; filename=ExtractResult.docx");
                // FileStreamResult fm = new FileStream(new MemoryStream(memoryStream.ToArray()), "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        static void GenerateHeaderPartContent(HeaderPart part)
        {
            Header header1 = new Header() { MCAttributes = new MarkupCompatibilityAttributes() { Ignorable = "w14 wp14" } };
            header1.AddNamespaceDeclaration("wpc", "http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas");
            header1.AddNamespaceDeclaration("mc", "http://schemas.openxmlformats.org/markup-compatibility/2006");
            header1.AddNamespaceDeclaration("o", "urn:schemas-microsoft-com:office:office");
            header1.AddNamespaceDeclaration("r", "http://schemas.openxmlformats.org/officeDocument/2006/relationships");
            header1.AddNamespaceDeclaration("m", "http://schemas.openxmlformats.org/officeDocument/2006/math");
            header1.AddNamespaceDeclaration("v", "urn:schemas-microsoft-com:vml");
            header1.AddNamespaceDeclaration("wp14", "http://schemas.microsoft.com/office/word/2010/wordprocessingDrawing");
            header1.AddNamespaceDeclaration("wp", "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing");
            header1.AddNamespaceDeclaration("w10", "urn:schemas-microsoft-com:office:word");
            header1.AddNamespaceDeclaration("w", "http://schemas.openxmlformats.org/wordprocessingml/2006/main");
            header1.AddNamespaceDeclaration("w14", "http://schemas.microsoft.com/office/word/2010/wordml");
            header1.AddNamespaceDeclaration("wpg", "http://schemas.microsoft.com/office/word/2010/wordprocessingGroup");
            header1.AddNamespaceDeclaration("wpi", "http://schemas.microsoft.com/office/word/2010/wordprocessingInk");
            header1.AddNamespaceDeclaration("wne", "http://schemas.microsoft.com/office/word/2006/wordml");
            header1.AddNamespaceDeclaration("wps", "http://schemas.microsoft.com/office/word/2010/wordprocessingShape");

            Paragraph paragraph1 = new Paragraph() { RsidParagraphAddition = "00164C17", RsidRunAdditionDefault = "00164C17" };

            ParagraphProperties paragraphProperties1 = new ParagraphProperties();
            ParagraphStyleId paragraphStyleId1 = new ParagraphStyleId() { Val = "Header" };

            paragraphProperties1.Append(paragraphStyleId1);

            Run run1 = new Run();
            Text text1 = new Text();
            text1.Text = "Header";

            run1.Append(text1);

            paragraph1.Append(paragraphProperties1);
            paragraph1.Append(run1);

            header1.Append(paragraph1);
           
            part.Header = header1;
            header1.Save();
        }



        private string GetResult(string[] resultString)
        {
            string res = string.Empty;
            if(resultString.Length > 0) 
            { 
                if(resultString.Length == 2)
                {
                    res = resultString[1];
                }
                else if(resultString.Length > 2)
                {
                    for (int i = 1; i < resultString.Length; i++)
                    {
                        res += " " + resultString[i];
                    }
                }
            }
            return res;
        }

        static string FindNextLine(string[] lines, string searchText)
        {
            bool found = false;

            foreach (string line in lines)
            {
                if (found)
                {
                    // Return the next line after the line with the provided text
                    return System.IO.Path.GetFileName(line.Replace("\\par", "")) + Environment.NewLine;

                }

                if (line.Trim().Contains(searchText.Trim()))
                {
                    found = true;
                }
            }

            // If the provided text was not found or it's the last line, return null or an empty string
            return "N/A"; // or return string.Empty;
        }
        private TableCell CreateHeaderCell(string text)
        {
            TableCell cell = new TableCell();
            TableCellProperties prop = new TableCellProperties();
            var shading = new Shading()
            {
                Color = "auto",
                Fill = "FFFACD",
                Val = ShadingPatternValues.Clear
            };
            prop.Append(shading);
            cell.Append(prop);
            Paragraph paragraph = new Paragraph(new Run(new Text(text)));
            paragraph.ParagraphProperties = new ParagraphProperties(new Justification { Val = JustificationValues.Center });
            cell.Append(paragraph);
            return cell;
        }

        private TableCell CreateCell(string text)
        {
            TableCell cell = new TableCell();
            Paragraph paragraph = new Paragraph(new Run(new Text(text)));
            paragraph.ParagraphProperties = new ParagraphProperties(new Justification { Val = JustificationValues.Center });
            cell.Append(paragraph);
            return cell;
        }
        private TableCell CreateCategoryCell(string text)
        {
            TableCell cell = new TableCell();
            TableCellProperties prop = new TableCellProperties();
            var shading = new Shading()
            {
                Color = "auto",
                Fill = "D3D3D3",
                Val = ShadingPatternValues.Clear
            };
            prop.Append(shading);
            cell.Append(prop);
            Paragraph paragraph = new Paragraph(new Run(new Text(text)));
            paragraph.ParagraphProperties = new ParagraphProperties(new Justification { Val = JustificationValues.Left });
            cell.Append(paragraph);
            return cell;
        }
        private TableCell CreateTestDesCell(string text)
        {
            string[] str = text.Split("And",StringSplitOptions.RemoveEmptyEntries);

            TableCell cell = new TableCell();
            Paragraph paragraph = new Paragraph();// new Run(new Text(text)));
            Run run = new Run();
            if (str.Length > 1)
            {
                run.Append(new Text("Refer to :"));
                run.AppendChild(new Break());
                run.AppendChild(new Text(str[0]));
                run.AppendChild(new Break());
                run.AppendChild(new Text("And"));
                run.AppendChild(new Break());
                run.AppendChild(new Text(str[1]));
            }
            else
            {
                run.AppendChild(new Text(text));
            }
            paragraph.AppendChild(run);
            paragraph.ParagraphProperties = new ParagraphProperties(new Justification { Val = JustificationValues.Left });
            cell.Append(paragraph);
            return cell;
        }
        private TableCell CreateRightCell(string text)
        {
            TableCell cell = new TableCell();// new TableCellProperties(new TableCellWidth { Type = TableWidthUnitValues.Pct, Width = "3000" }));
           TableCellProperties tcp = new TableCellProperties(new TableCellWidth { Type = TableWidthUnitValues.Pct, Width = "3000" });

            cell.Append(tcp);
            Paragraph paragraph = new Paragraph(new Run(new Text(text)));
            paragraph.ParagraphProperties = new ParagraphProperties(new Justification { Val = JustificationValues.Left });
            cell.Append(paragraph);
            return cell;
        }
    }
    public class TestModel
    {
        public string TestName { get; set; }
        public string TestResult { get; set; }
        public string TestDescription { get; set; }
    }
}